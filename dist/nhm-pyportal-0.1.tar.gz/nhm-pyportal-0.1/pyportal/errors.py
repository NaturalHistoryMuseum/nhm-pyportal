class ParameterMissingError(Exception):
    pass


class IncorrectURLError(Exception):
    pass
